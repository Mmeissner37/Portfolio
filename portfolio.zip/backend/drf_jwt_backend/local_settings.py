# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'q*h=-w2+4h&0k+tv=27xr=^v8lqzmvm(rm#d#7u@bk*e8x^6!'



# Database
# https://docs.djangoproject.com/en/4.1/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'mysql.connector.django',
        'NAME': 'portfolio_database',
        'USER': 'root',
        'PASSWORD': 'password',
        'HOST': 'portfolio-database',
        # 'HOST': "localhost",
        'PORT': "3306",
        'OPTIONS': {
            'autocommit': True
        }
    }
}
